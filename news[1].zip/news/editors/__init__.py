# -*- coding: utf-8 -*-

import os
import sys


here = os.path.dirname(os.path.abspath(__file__))
sys.path.append(here)
